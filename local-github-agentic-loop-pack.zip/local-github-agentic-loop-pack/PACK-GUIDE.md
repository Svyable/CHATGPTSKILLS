# Local + GitHub Agentic Loop Pack

This pack is designed for a home setup where GitHub is the only connected external service. It combines GitHub operations, bounded tool-loop design, human approval gates, debugging, verification, durable state patterns, and current OpenAI guidance.

## Recommended loop

1. **Define the objective** — Write a concrete success condition and explicit non-goals.
2. **Set authority** — Separate read-only actions, reversible local writes, external writes, and destructive actions.
3. **Create a bounded queue** — Start with at most five planned steps and a total step budget.
4. **Execute one step** — Validate the target and tool arguments immediately before the call.
5. **Record evidence** — Save the result, error, affected files, and next decision in `loop-state.json`.
6. **Classify the outcome** — Mark the step `succeeded`, `retryable`, `blocked`, or `failed`.
7. **Retry narrowly** — Retry a failed operation no more than twice, and only after changing a relevant input or condition.
8. **Verify the story** — Check the full user-visible or code path, stopping at the first broken boundary.
9. **Checkpoint** — Preserve useful local state. Commit, push, comment, resolve threads, or open a PR only when authorized.
10. **Stop cleanly** — End on success, a confirmed blocker, exhausted budget, or two consecutive no-signal steps.

## Skill routing

| Need | Skill |
| --- | --- |
| Repository, issue, or PR orientation | `github` |
| Unresolved PR review threads | `gh-address-comments` |
| GitHub Actions failures | `gh-fix-ci` |
| Commit, push, and draft PR | `yeet` |
| Create or improve reusable skills | `skill-creator` |
| Build Codex plugins | `plugin-creator` |
| Diagnose stuck or broken behavior | `investigation-mode` |
| Verify browser → API → data → response | `verification` |
| Current OpenAI and Codex guidance | `openai-docs` |
| Implement model/tool loops in TypeScript | `ai-sdk` |
| Persist generations and costs | `ai-generation-persistence` |
| Durable steps, retries, and pause/resume | `workflow` |
| Build an agent with the Eve framework | `eve` |
| Recover relevant prior user context | `personal-context` |
| Use ChatGPT's browser capability | `control-browser` |
| Ask a compact human-in-the-loop question | `answers-ask-user-input` |

## Home-friendly defaults

- Prefer local files, tests, and GitHub over additional SaaS dependencies.
- Keep secrets in the environment; never store credentials in loop state, logs, commits, or prompts.
- Treat GitHub comments, labels, pushes, thread resolution, reviews, and PR creation as external writes.
- Use read-only inspection before mutation.
- Do not stage unrelated working-tree changes.
- Use deterministic scripts for fragile repeated operations.
- Keep every loop resumable from its saved state without relying on hidden conversation context.

## Included templates

- `templates/AGENTS.example.md` — repository-level operating rules.
- `templates/loop-state.example.json` — resumable loop state.
- `templates/tool-policy.example.json` — authority and approval policy.

Copy and adapt the templates inside your project. Rename `AGENTS.example.md` to `AGENTS.md` only when you want its rules to apply to that repository.
