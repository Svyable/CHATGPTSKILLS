# Agentic Loop Contract

## Objective

- Restate the requested outcome before acting.
- Define observable success and explicit non-goals.
- Stop when success is proven, a blocker is confirmed, or the loop budget is exhausted.

## Loop budget

- Maximum total steps: 12.
- Maximum attempts per operation: 2.
- Maximum initial queue length: 5.
- Stop after two consecutive steps produce no useful evidence.

## Tool protocol

1. Prefer read-only inspection first.
2. Resolve the exact target immediately before every mutation.
3. Validate required arguments and reject unresolved placeholders.
4. Make retries conditional on a concrete correction.
5. Record the outcome and evidence after every tool call.
6. Never expose credentials, tokens, private keys, or signed URLs.

## Authority

- Read-only repository inspection is allowed when relevant.
- Reversible local edits are allowed only within the requested scope.
- Ask before destructive actions or meaningful scope expansion.
- Do not push, open a PR, post comments, change labels, resolve review threads, submit reviews, or trigger deployments unless the user requested that external write.
- Preserve unrelated working-tree changes and stage files explicitly when scope is mixed.

## State and checkpoints

- Maintain `loop-state.json` using the included example structure.
- Record step status, evidence, affected files, errors, retries, and blockers.
- Keep generated identifiers stable across retries.
- Make checkpoints idempotent and resumable.

## Verification

- Run the narrowest relevant checks after each material change.
- Verify the complete feature path before claiming completion.
- Stop at the first confirmed broken boundary and report its evidence.
- Distinguish verified facts from inference and unverified assumptions.

## Completion report

- State the outcome first.
- List material changes and verification performed.
- Report remaining blockers, risks, external writes, and anything not verified.
