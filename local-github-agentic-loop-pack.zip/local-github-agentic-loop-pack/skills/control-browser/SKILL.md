---
name: control-browser
description: "Control a cloud browser for explicit site actions: open, navigate, inspect, click, or 'use my [site] to...'. Load ONLY for direct interaction. Information lookups—public profiles/listings ABOUT or FROM a service, page titles/metadata, current facts—use web search. Signed-in sessions may be reused. Creating, reading, writing, or acting on provider resources (documents, email, files) is plugin-owned, NOT site interaction; a resource URL does not make it explicit. Without explicit site intent, NEVER load/read/initialize/use Browser, assume/probe for a session, or suggest login, even for unavailable/failed plugins. For explicit login or an observed sign-in wall blocking an independently requested site task, offer manual takeover on chatgpt.com unless told to stop at login; never substitute web search or accept credentials or sensitive information in chat."
---

# Browser
Use this skill for browser automation tasks such as inspecting pages, navigating, testing local apps, clicking, typing, taking screenshots, and reading visible page state.

If this skill is listed as available in the session, treat that as mandatory reading before browser work. Open and follow this skill before saying that Browser is unavailable and before falling back to standalone Playwright or Computer Use.

Do not skip this skill just because Computer Use MCP tool calls are directly visible or appear easier to invoke. The presence of Computer Use tools is not evidence that Computer Use is the preferred browser surface.

## Setup Documentation
Use `await agent.documentation.get("<name>")` when one of these setup topics applies:
- `bootstrap-troubleshooting`: read when browser setup succeeds but discovery or selection fails

## Bootstrap
These setup details are internal. User-facing progress updates should be less technical in nature. Never mention `Node REPL`, `node_repl`, `REPL`, JavaScript sessions, module exports, reading documentation, or loading instructions unless a user is asking for that exact information. If setup or recovery is needed, describe it naturally as connecting to the browser or retrying the browser connection.

The `browser-client` module is the core entry point for browser use, and is available under `scripts/browser-client.mjs` in this skill's root directory. ALWAYS import it using an absolute path.
IMPORTANT: Do not check whether this path exists with shell commands, `exec_command`, or any other method. If the import through the Node REPL `js` tool in the example below fails, stop and report that this skill is missing `scripts/browser-client.mjs`. Do not fall back to importing `browser-client` by package name, for example `await import("browser-client")`. Use only the exact file import shown below.

Run browser setup code through the Node REPL `js` tool. In this environment the callable tool id typically appears as `mcp__node_repl__js`. If it is not already available, use tool discovery for `node_repl js` without setting a result limit. You need the `js` execution tool: `js_reset` only clears state, and `js_add_node_module_dir` only changes package resolution. Do not call either helper while trying to expose `js`. If `js` is still not available, search again for `node_repl js` with `limit: 10`. Run this once per fresh `node_repl` session:

CODE MODE REQUIREMENT: When you call the Node REPL `js` tool from the code-mode `exec` tool, the outer `exec` script containing the initial `documentation()` call MUST begin with `// @exec: {"max_output_tokens": 20000}`. This is a first-line pragma for the outer `exec` call, not an argument to the nested `js` tool. Keep the exact `nodeRepl.write(await browser.documentation());` call below and forward its complete result.

```js
const { setupBrowserRuntime } = await import("<skill root>/scripts/browser-client.mjs");
await setupBrowserRuntime({ globals: globalThis, elicitationDisplayName: "Cloud browser" });
globalThis.browser = await agent.browsers.get("cdp");
nodeRepl.write(await browser.documentation());
```

If setup succeeds but browser discovery or selection fails, read `await agent.documentation.get("bootstrap-troubleshooting")` before resetting the JavaScript session or trying another browser-control mechanism.

Use the browser bound to `browser` for tasks in this skill.

The ability to interact directly with the browser is exposed through the `browser-client` runtime via the `agent.browsers.*` API. Before trying to interact with it, you MUST emit and read the complete documentation returned by `await browser.documentation()` in one go. For the initial documentation read, run the exact direct call `nodeRepl.write(await browser.documentation());` shown above. Do not assign the documentation to a variable, inspect its length, slice it, truncate it, summarize it, or emit only an excerpt. Do not proactively split the documentation into pages or chunks. Only if the tool output itself explicitly reports that it was truncated may you emit and read smaller chunks until you have read the documentation in its entirety.

Only the Node REPL `js` tool (`mcp__node_repl__js`) can be used to control the browser. Do not use external MCP browser-control tools, separate browser automation servers, or other browser skills for this surface. References to Playwright mean the in-skill `tab.playwright` API after browser-client setup.

<!-- BROWSER_SKILL_EOF: This is the complete Browser skill. Do not request additional lines. -->
