from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

if __package__:
    from ..runtime import render_standalone_visualization
else:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from runtime import render_standalone_visualization


_MAX_FRAGMENT_BYTES = 1_000_000
_DOCUMENT_MARKUP = re.compile(r"<!doctype\s|<\s*(?:html|head|body)(?:\s|>)", re.IGNORECASE)
_HOST_API_REFERENCE = re.compile(r"\b(?:window|globalThis)\.openai\b")
_ASSETS_DIRECTORY = Path(__file__).resolve().parents[1] / "assets"


def _read_asset(name: str) -> str:
    return (_ASSETS_DIRECTORY / name).read_text(encoding="utf-8")


def _default_title(source: Path) -> str:
    words = source.stem.replace("-", " ").replace("_", " ").split()
    return " ".join(word.capitalize() for word in words) or "Visualization"


def export_html(
    source: Path,
    destination: Path,
    *,
    title: str | None = None,
    force: bool = False,
) -> bool:
    if source.is_symlink() or not source.is_file():
        raise ValueError(f"source must be a regular file: {source}")
    if source.stat().st_size > _MAX_FRAGMENT_BYTES:
        raise ValueError("source fragment exceeds the 1 MB size limit")
    if destination.is_symlink():
        raise ValueError(f"destination cannot be a symbolic link: {destination}")
    if source.resolve() == destination.resolve():
        raise ValueError("source and destination must be different files")

    fragment = source.read_text(encoding="utf-8")
    if _DOCUMENT_MARKUP.search(fragment):
        raise ValueError("source must be an HTML fragment, not a complete document")

    document = render_standalone_visualization(
        fragment,
        title=title or _default_title(source),
        stylesheet=_read_asset("visualize.css"),
        runtime_dependencies=_read_asset("runtime-dependencies.html"),
        tooltip_runtime=_read_asset("tooltip-runtime.js"),
        lucide_initialization=_read_asset("lucide-initialization.js"),
    )

    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w" if force else "x", encoding="utf-8", newline="\n") as output:
        output.write(document)
    return _HOST_API_REFERENCE.search(fragment) is not None


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Export an HTML fragment as a standalone visualization.",
    )
    parser.add_argument("source", type=Path, help="HTML fragment to export")
    parser.add_argument("destination", type=Path, help="standalone HTML file to write")
    parser.add_argument("--title", help="document title; defaults to the source file name")
    parser.add_argument(
        "--force",
        action="store_true",
        help="replace the destination if it already exists",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    if args.destination.exists() and not args.force:
        parser.error("destination already exists; pass --force to replace it")
    try:
        references_host_api = export_html(
            args.source,
            args.destination,
            title=args.title,
            force=args.force,
        )
    except (OSError, UnicodeError, ValueError) as exc:
        parser.error(str(exc))
    if references_host_api:
        print(
            "warning: the source references window.openai; adapt that interaction "
            "if the destination does not provide the API",
            file=sys.stderr,
        )
    print(args.destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
