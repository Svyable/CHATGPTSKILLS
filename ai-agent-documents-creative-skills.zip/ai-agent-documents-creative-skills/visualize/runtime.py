from __future__ import annotations

from collections.abc import Sequence
from html import escape


def _inline_script(script_id: str, source: str) -> str:
    safe_source = source.replace("</script", "<\\/script")
    return f'<script id="{script_id}">{safe_source}</script>'


def _runtime_scripts(
    *,
    runtime_dependencies: str,
    tooltip_runtime: str,
    lucide_initialization: str,
) -> tuple[str, ...]:
    return (
        runtime_dependencies.strip(),
        _inline_script("codex-visualization-tooltip", tooltip_runtime),
        _inline_script("codex-visualization-lucide-initialization", lucide_initialization),
    )


def render_embedded_visualization(
    fragment: str,
    *,
    stylesheet: str,
    runtime_dependencies: str,
    tooltip_runtime: str,
    lucide_initialization: str,
    before_fragment: Sequence[str] = (),
    after_fragment: Sequence[str] = (),
) -> str:
    return "\n".join(
        (
            f"<style>{stylesheet}</style>",
            *before_fragment,
            fragment,
            *after_fragment,
            *_runtime_scripts(
                runtime_dependencies=runtime_dependencies,
                tooltip_runtime=tooltip_runtime,
                lucide_initialization=lucide_initialization,
            ),
        )
    )


def render_standalone_visualization(
    fragment: str,
    *,
    title: str,
    stylesheet: str,
    runtime_dependencies: str,
    tooltip_runtime: str,
    lucide_initialization: str,
) -> str:
    scripts = _runtime_scripts(
        runtime_dependencies=runtime_dependencies,
        tooltip_runtime=tooltip_runtime,
        lucide_initialization=lucide_initialization,
    )
    return "\n".join(
        (
            "<!doctype html>",
            '<html lang="en" data-visualize-standalone>',
            "<head>",
            '<meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1">',
            '<meta name="referrer" content="no-referrer">',
            f"<title>{escape(title)}</title>",
            f"<style>{stylesheet}</style>",
            "</head>",
            "<body>",
            fragment,
            *scripts,
            "</body>",
            "</html>",
            "",
        )
    )
