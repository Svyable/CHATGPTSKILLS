---
name: writing-blocks
description: Display drafted text in a user-editable writing block. Use for complete drafts of emails, chat messages, social media posts, paragraphs, assignment answers, speeches, stories, scripts, and other prose. Prefer creating or editing a file for standalone documents or long-form content such as reports and proposals instead of a writing block.
---

# Writing Blocks

A writing block fences the drafted text into a distinct section that is easy to view, copy, and modify.

## Usage

Use a writing block whenever the user asks for a complete drafted piece of short form writing such as emails, chat messages, and social media posts.

When revising a prior writing block, return the revised content in a new writing block.

Do not use a writing block for critique, brainstorming, summaries, short snippets, or wording suggestions unless the user asks for a complete draft.

## Syntax

Use this format:

:::writing{variant="<variant>" id="<id>"}
<content>
:::

For emails:

:::writing{variant="email" id="<id>" subject="<subject>" recipient="<recipient>"}
<content>
:::

## Variants

Set `variant` to one of:

- `email`
- `chat_message`
- `social_post`
- `document`
- `standard`

Variant choice:
- Use variant="chat_message" for rewritten texts, Slack replies, DMs, quick replies, and direct messages.
- Use variant="social_post" for rewritten captions, social posts, LinkedIn posts, tweets/X posts, Instagram captions, and promotional social copy.
- Use variant="document" for paragraphs, essays, assignment answers, speeches, stories, scripts, and statements.
- Use variant="standard" only when required but no specific surface fits.

## Metadata Rules

Writing blocks should always include:

- `variant`
- `id`

Set `id` to a unique 5-digit string.

For `variant="email"`:

- Always include `subject`.
- If the user specifies a recipient, try to determine the email address from available context or tools and include it as `recipient`.
- Only include a recipient if the email address is known. Do not invent or guess an email address.
- Omit `recipient` if the email address cannot be determined.

For non-email variants:

- Do not include `subject` or `recipient`.

## Output Rules

Put the complete draft inside the writing block.

If the user asks for multiple complete drafts, use one writing block per draft, each with a unique `id`.

Keep any surrounding explanation brief unless the user asks for rationale or alternatives.

When replying to a retrieved email, use that email's sender address unchanged as the `recipient` and its message `id` unchanged as the `reference_message_id`. Set `email_provider="gmail"` when the email came from a Gmail tool and `email_provider="outlook"` when it came from an Outlook tool. Include `recipient="<retrieved email sender address>" email_action="reply" reference_message_id="<retrieved email message id>" email_provider="<gmail or outlook>"` in the opening `:::writing{...}` metadata. Never invent or modify the sender address or message ID. Only emit the three reply-specific fields when the sender address, message ID, and provider are all available.
